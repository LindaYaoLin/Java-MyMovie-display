package Interface;

public interface MarvelSeries {
    public void printseries();
}
