package Interface;

import java.io.IOException;

public interface Loadable {
    void load(String str) throws IOException;
}
