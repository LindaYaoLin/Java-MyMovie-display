package Interface;

import implementation.account;

import java.io.IOException;
import java.util.Observable;


public interface Saveble {
    void save(account a) throws IOException;
}
