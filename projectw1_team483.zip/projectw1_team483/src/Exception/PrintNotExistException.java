package Exception;

public class PrintNotExistException extends Exception {
}
