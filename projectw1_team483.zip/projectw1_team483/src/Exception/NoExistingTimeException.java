package Exception;

public class NoExistingTimeException extends Exception {
}
