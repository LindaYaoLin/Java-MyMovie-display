package Exception;

public class MovieNotExistException extends Exception {
}
