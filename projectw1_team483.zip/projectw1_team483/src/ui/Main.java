package ui;

import Exception.MovieNotExistException;
import Exception.NoExistingTimeException;
import Exception.PrintNotExistException;
import Interface.Loadable;
import Interface.MarvelSeries;
import implementation.*;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

import javax.swing.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

public class Main {
    private static final String RETURN = "return";
    SetUpMovies sum = new SetUpMovies();


    public Main(Map<String, ArrayList<AbstMovies>> Movies) throws PrintNotExistException {
        Scanner scanner1 = new Scanner(System.in);
        System.out.println("------------ You are now in the MyMovie information console.----------");
        System.out.println("                                             ");
        Registration rt = new Registration();
        rt.PrintInstructions();

        String Scanned;
        Scanned = scanner1.nextLine();
        if (Scanned.equals("CF")) {
            ScannedCF(Movies);
        } else if (Scanned.equals("RS")) {
            ScannedRS(Movies);
        } else if (Scanned.equals("CS")) {
            ScannedCS();
        } else if (Scanned.equals("MV")) {
            ScannedMV();
        } else if (Scanned.equals("LM")) {
            ScannedLM();
        } else if (Scanned.equals("MS")) {
            ScannedMS();
        } else if (Scanned.equals("quit")) {
            System.exit(0);
        } else {
            throw new PrintNotExistException();
        }
    }


    public void ScannedCF(Map<String, ArrayList<AbstMovies>> Movies) {
        Scanner scanner = new Scanner(System.in);
        printCFStatement();
        while (true) {
            int num = 0;
            String Classification;
            Classification = scanner.nextLine();
            System.out.println("you selected: " + Classification);
            if (Classification.matches("Marvel|Comedy|Romance|Thriller")) {
                System.out.println("Movies available: ");
                for (String key : Movies.keySet()) {
                    if (key.equals(Classification)) {
                        for (AbstMovies m : Movies.get(key)) {
                            m.print();
                            num++;
                        }
                    }
                }
                int count = num;
                System.out.println("Total number of movies available: " + count);
            } else if (Classification.equals("return")) {
                main(new String[0]);
            } else if (Classification.equals("quit")) {
                break;
            }
        }
    }


    public void ScannedRS(Map<String, ArrayList<AbstMovies>> Movies) throws PrintNotExistException {
        Registration rt = new Registration();
        try {
            rt.account(Movies);
        } catch (MovieNotExistException e) {
            printRSStatement("NE", Movies);
        } catch (NoExistingTimeException e) {
            printRSStatement("NET", Movies);
        } finally {
            System.out.println("Thank you for your patience");
        }
        main(new String[0]);
    }


    public void ScannedCS() {
        Loadable ld = new SaveLoad();
        try {
            ld.load("inputfile.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void ScannedMV() {
        try {
            Website.main(null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void ScannedLM() {
        GUI.main(new String[0]);
    }

    public void ScannedMS() {
      //  MarvelSeries ms = sum.setupMarvelseries();
        sum.setupMarvelseries().printseries();
        main(new String[0]);
    }


    public void printRSStatement(String s, Map<String, ArrayList<AbstMovies>> Movies) throws PrintNotExistException {
        if (s.equals("NE")) {
            System.out.println("Sorry, we currently do not have the movie in theater, please try again");
        }
        if (s.equals("NET")) {
            System.out.println("Sorry we are closed at this time, please try again ");
        }

        Main m2 = new Main(Movies);
        m2.main(new String[0]);
    }


    public void printCFStatement() {
        System.out.println("                          ");
        System.out.println("Please select a movie type: ");
        System.out.println("Enter '" + RETURN + "' to go back to main menu");
    }

    public static void main(String[] args) {
        Map<String, ArrayList<AbstMovies>> Movies = new HashMap<>();
        SetUpMovies sum = new SetUpMovies();
        sum.setupMovies(Movies);
        try {
            new Main(Movies);
        } catch (PrintNotExistException e) {
            System.out.println("Sorry I didn't understand that comment, please try again");
            main(new String[0]);
        }
    }
}

