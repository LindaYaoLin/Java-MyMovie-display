package ui;

import implementation.SetUpMovies;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class GUI implements ActionListener{

    private static final String SM = "SpiderMan";
    private static final String HP = "HarryPotter";
    SetUpMovies sum = new SetUpMovies();
    JFrame frame = new JFrame("LearnMore");
    JPanel panel = new JPanel();
    JTextField txtName = new JTextField("",20);
    JButton button = new JButton("Enter");

    public GUI(){
        //playMusic("25.mp3");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1300,700);
        ImageIcon icon = new ImageIcon("C:\\lab\\image.jpg");
        JLabel l = new JLabel("Welcome to MyMovie Family cinema");
        l.setBounds(500,60,500,100);
        JLabel label = new JLabel("Please enter the movie you want to know more about:");
        label.setBounds(400,420,500,100);
        panel.setLayout(null);
        frame.add(panel);
        button.setBounds(1000,480,200,70);
        txtName.setBounds(400,500,500,50);
        frame.setFont(new Font("Calibri",Font.BOLD,1000));
        JLabel L = new JLabel("",icon,JLabel.CENTER);
        L.setBounds(400,100,500,400);

        panel.add(txtName);
        panel.add(button);
        panel.add(label);
        panel.add(L);
        panel.add(l);
        frame.setVisible(true);
        button.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e){
        String LM1 = txtName.getText();
        if(LM1.equals("HarryPotter")){
            JOptionPane.showMessageDialog(frame,"You selected '" + HP + " '");
            JFrame frame3 = new JFrame("HarryPotter");
            frame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame3.setSize(800,650);
            JPanel panel3 = new JPanel();
            ImageIcon icon = new ImageIcon("C:\\lab\\hp1.jpg");
            JLabel label3 = new JLabel("HarryPotter",icon, JLabel.CENTER);
            panel3.add(label3);
            label3.setIcon(icon);
            frame3.add(panel3);
            JButton b = new JButton("Next");
            b.setBounds(1000,480,200,70);
            JButton b1 = new JButton("Previous");
            b1.setBounds(1200,500,600,70);
            b.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    label3.setIcon(new ImageIcon("C:\\lab\\HP.jpg"));
                    b1.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent e){
                            label3.setIcon(new ImageIcon("C:\\lab\\hp1.jpg")) ;
                        }});
                }});
            panel3.add(b);
            panel3.add(b1);
            frame3.setVisible(true);
            sum.setupInformation2();
            System.out.println("////////////////////////////");
        }
        else if(LM1.equals("SpiderMan")){
            JOptionPane.showMessageDialog(frame,"You selected '" + SM + " '");
            JFrame frame2 = new JFrame("SpiderMan");
            frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame2.setSize(1000,600);
            JPanel panel2 = new JPanel();
            ImageIcon icon = new ImageIcon("C:\\lab\\untitled.png");
            JLabel label2 = new JLabel("SpiderMan",icon, JLabel.CENTER);
            panel2.add(label2);
            label2.setIcon(icon);
            frame2.add(panel2);
            JButton b = new JButton("Next");
            b.setBounds(1000,480,200,70);
            JButton b1 = new JButton("Previous");
            b1.setBounds(1200,500,600,70);
            b.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    label2.setIcon(new ImageIcon("C:\\lab\\p1.jpg"));
                    b1.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent e){
                        label2.setIcon(new ImageIcon("C:\\lab\\untitled.png")) ;
                        }});
                }});
            panel2.add(b);
            panel2.add(b1);
            frame2.setVisible(true);
            sum.setupInformation();
            System.out.println("///////////////////////////");
        }
       else{
           JOptionPane.showMessageDialog(frame,"Invalid Movie name");
        }
    }

    public static void main(String[] args){
        SwingUtilities.invokeLater(new Runnable(){
            public void run(){
                new GUI();
            }
        });
    }
}
