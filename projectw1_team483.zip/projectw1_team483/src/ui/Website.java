package ui;
import java.awt.Desktop;
import java.net.URI;
import java.util.Scanner;
import Exception.PrintNotExistException;

public class Website {



    public Website(){};

    public static void main(String[] args) throws Exception {
        Scanner scanner2 = new Scanner(System.in);
        System.out.println("Please select a movie: ");
        String scanns;
        scanns = scanner2.nextLine();
        Desktop d = Desktop.getDesktop();
        Scanner scanner3 = new Scanner(System.in);
            System.out.println("What kind of information would you like to know? Please select from below");
            System.out.println("-- Rating");
            System.out.println("-- Trailer");
            System.out.println("-- Introduction");
            String scannss;
            scannss = scanner3.nextLine();
            if (scannss.equals("Introduction")) {
                if (scanns.equals("Venom")) {
                    d.browse(new URI("https://en.wikipedia.org/wiki/Venom_(2018_film)"));
                }
                if(scanns.equals("Thor:Ragnarok")){
                    d.browse(new URI("https://en.wikipedia.org/wiki/Thor:_Ragnarok"));
                }
                if(scanns.equals("The Grand Budapest Hotel")){
                    d.browse(new URI("https://en.wikipedia.org/wiki/The_Grand_Budapest_Hotel"));
                }
                if(scanns.equals("Spider-Man: Homecoming")){
                    d.browse(new URI("https://en.wikipedia.org/wiki/Spider-Man:_Homecoming"));
                }
                if(scanns.equals("Pride and prejudice")) {
                    d.browse(new URI("https://en.wikipedia.org/wiki/Pride_and_Prejudice"));
                }
                if(scanns.equals("Split")) {
                    d.browse(new URI("https://en.wikipedia.org/wiki/Split_(2016_American_film)"));
                }
                else{ throw new PrintNotExistException();}
            }

            if (scannss.equals("Trailer")) {
                if (scanns.equals("Venom")) {
                    d.browse(new URI("https://www.youtube.com/watch?v=u9Mv98Gr5pY"));
                }
                if(scanns.equals("Thor:Ragnarok")){
                    d.browse(new URI("https://www.youtube.com/watch?v=v7MGUNV8MxU"));
                }
                if(scanns.equals("The Grand Budapest Hotel")){
                    d.browse(new URI("https://www.youtube.com/watch?v=1Fg5iWmQjwk"));
                }
                if(scanns.equals("Spider-Man: Homecoming")){
                    d.browse(new URI("https://www.youtube.com/watch?v=n9DwoQ7HWvI"));
                }
                if(scanns.equals("Pride and prejudice")){
                    d.browse(new URI("https://www.youtube.com/watch?v=ARWfCBr0ZDM"));
                }
                if(scanns.equals("Split")) {
                    d.browse(new URI("https://www.youtube.com/watch?v=ROVc_47FUD8"));
                }
                else{
                    System.out.println("Sorry we don't have the information for this movie");
                    main(new String[0]);}
            }
            if (scannss.equals("Rating")) {
                if (scanns.equals("Venom")) {
                    d.browse(new URI("https://www.rottentomatoes.com/m/venom_2018/"));
                }
                if(scanns.equals("Thor:Ragnarok")){
                    d.browse(new URI("https://www.rottentomatoes.com/m/thor_ragnarok_2017/"));
                }
                if(scanns.equals("The Grand Budapest Hotel")){
                    d.browse(new URI("https://www.rottentomatoes.com/m/the_grand_budapest_hotel"));
                }
                if(scanns.equals("Spider-Man: Homecoming")){
                    d.browse(new URI("https://www.rottentomatoes.com/m/spider_man_homecoming/"));
                }
                if(scanns.equals("Pride and prejudice")){
                    d.browse(new URI("https://www.rottentomatoes.com/m/1153077_1153077_pride_and_prejudice?"));
                }
                if(scanns.equals("Split")){
                    d.browse(new URI("https://www.rottentomatoes.com/m/split_2017"));
                }
                else{
                    System.out.println("Sorry we don't have the information for this movie");
                    main(new String[0]);
                }
            }
            else {
                System.out.println("Sorry we currently don't have other information for the movie");
                main(new String[0]);
            }
        }
    }
