package implementation;


import java.util.ArrayList;
import java.util.List;

public class Movies extends AbstMovies {
    public List<MoviesCS> sequel;


    public Movies(String name) {
        super(name);
        sequel = new ArrayList<>();


    }

    @Override
    public void print() {
        System.out.println(name);
    }

    public String getname(){return name; }

    public void addsequel(MoviesCS mcs){
        if(!sequel.contains(mcs)){
            sequel.add(mcs);
            mcs.addprequel(this);
        }
    }

    public void printsequel(List<MoviesCS> s){
        for(MoviesCS cs : s){
            System.out.println(cs.getname());
        }
    }
}

