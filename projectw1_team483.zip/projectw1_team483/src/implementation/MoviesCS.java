package implementation;

import ui.Website;

import java.util.ArrayList;
import java.util.List;

public class MoviesCS extends AbstMovies {
    private int Date;
    public List<Movies> prequel;

    public MoviesCS( String name, int Date) {
        // this.name = name;
        super(name);
       // this.classification = classification;
        this.Date = Date;
        prequel = new ArrayList<>();

    }

    @Override
    public void print() {
        System.out.println(name + ": ----- Coming Soon On the " + Integer.toString(Date) + "th");
    }

    public String getname(){return name;}

    public void addprequel(Movies m){
        if(!prequel.contains(m)){
            prequel.add(m);
            m.addsequel(this);

        }
    }

    public void printprequel(List<Movies> m){
        for(Movies mm : m){
            System.out.println(mm.getname());
        }
    }

}

