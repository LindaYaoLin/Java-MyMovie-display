package implementation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

import Exception.NoExistingTimeException;
import Exception.MovieNotExistException;
import Exception.PrintNotExistException;
import ui.Main;


public class Registration {
    private static final String Classifications = "CF";
    private static final String Reservation = "RS";
    private static final String status = "CS";
    private static final String RETURN = "return";
    private static final String Movies = "MV";
    private static final String LearnMore = "LM";
    private static final String LearnSeries = "MS";



    public Registration() { }


    public void account(Map<String,ArrayList<AbstMovies>> Movies) throws MovieNotExistException, NoExistingTimeException, PrintNotExistException {
        MyMovie mm = new MyMovie();
        String scans;
        String scans1;
        String scans2;
        String scans3;
        PrintStatement(0);
        Scanner scanners = new Scanner(System.in);
        scans = scanners.nextLine();

        if (!scans.equals("return")) {
            PrintStatement(1);
        } else {
            ElseStatement(Movies);
        }

        Scanner scanners1 = new Scanner(System.in);
        scans3 = scanners1.nextLine();
        if (!scans3.equals("return")) {
            PrintStatement(2);
        } else {
            ElseStatement(Movies);
        }

        Scanner scanners3 = new Scanner(System.in);
        scans1 = scanners3.nextLine();
        if (!scans1.equals("return")) {
            PrintStatement(3);
        } else {
            ElseStatement(Movies);
        }

        Scanner scanners2 = new Scanner(System.in);
        scans2 = scanners2.nextLine();
        if (!scans2.equals("return")) {
            System.out.println("-----Make and conform reservation-----");
            MakeandConform(scans,scans1,scans2,scans3,Movies,mm);
        } else {
            ElseStatement(Movies);
        }
    }




    public void MakeandConform(String scans,String scans1,String scans2,String scans3, Map<String,ArrayList<AbstMovies>> Movies,MyMovie mm)
            throws MovieNotExistException, NoExistingTimeException{
        if (!(8 <= Integer.parseInt(scans2) && Integer.parseInt(scans2) <= 20)) {
            throw new NoExistingTimeException();
        }
        AbstMovies am = new Movies(scans1);
        for(String key: Movies.keySet()) {
            if (key.equals(scans3)) {
                if (Movies.get(key).contains(am)) {
                    account a = new account(scans, scans1);
                    try {
                        a.save(a);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    System.out.println("---------------------");
                    mm.MakeNewReservation(a, Integer.parseInt(scans2));
                    mm.verifyReservation(a, Integer.parseInt(scans2));
                    a.confirmation();

                    System.out.println("--------------Check booking by name---------------");
                    System.out.println("Can we find the customer by name? " + mm.confirmReservedName(scans, Integer.parseInt(scans2)));

                    PrintingBooking(mm);
                    String scanned1;
                    Scanner scanners5 = new Scanner(System.in);
                    scanned1 = scanners5.nextLine();
                    if (scanned1.equals(status)) {
                        try {
                            a.load("outputfile.txt");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                else {
                    throw new MovieNotExistException();
                }
            }
        }
    }





    public void PrintStatement(int i){
        if(i == 0){
            System.out.println("Please create a new account by: ");
            System.out.println("Entering your name");
        }
        if(i == 1){
            System.out.println("the classification of the movie");
        }
        if(i == 2){
            System.out.println("the movie you would like to watch");
        }
        if(i == 3){
            System.out.println("And the time you would like reserve");
        }
        System.out.println("Enter '" + RETURN + "' to go back to main menu");
    }



    public void ElseStatement(Map<String,ArrayList<AbstMovies>> Movies) throws PrintNotExistException {
        Main m = new Main(Movies);
        m.main(new String[0]);
    }



    public void PrintingBooking(MyMovie mm){

        System.out.println("--------------------------------------------------");
        System.out.println("All the bookings for the day:");
        System.out.println("--------------------------------------------------");
        mm.PrintReservation();
        System.out.println("--------------------------------------------------");
        System.out.println("Please enter '" + status + " 'to check your reservation status");
    }




    public void PrintInstructions() {
        System.out.println("Please choose from the options below: ");
        System.out.println("- Enter '" + Reservation + "' to make a registration");
        System.out.println("- Enter '" + Classifications + "' to select a classification");
        System.out.println("- Enter '" + status + "' to check reservation status" );
        System.out.println("- Enter '" + Movies  + "' to obtain more information about a movie");
        System.out.println("- Enter '" + LearnMore + "' to learn more about related movies" );
        System.out.println("- Enter '" + LearnSeries + "' to learn more about Marvel series" );
    }

    }



