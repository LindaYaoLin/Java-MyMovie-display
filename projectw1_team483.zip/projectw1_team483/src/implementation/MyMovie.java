package implementation;


import java.util.ArrayList;
import java.util.Objects;

public class MyMovie {

    private ArrayList<account> Reservation;
    private int maxTime;

    // EFFECT: construct a MyMovie with the max time the store opens and a list of account.
    public MyMovie() {
        maxTime = 20;
        Reservation = new ArrayList<>();
        for (int i = 0; i <= maxTime; i++) {
            Reservation.add(i, null);
        }
    }

    // MODIFIES: this and account
    // EFFECTS:  reserve the customer into the requested timeslot if it is a valid and let's the customer know
    // the reservation time and what movie they had reserved.
    public void MakeNewReservation(account a, int ReservationTime ){
        System.out.println("The customer has been booked at " + ReservationTime);
        Reservation.set(ReservationTime,a);
        a.setReservationTime(ReservationTime);
    }

    // EFFECT: print out all the time customers can reserve. If a time has not been reserved,
    // print out "available" next to it.
    public void PrintReservation(){
        for (int i = 8; i< Reservation.size(); i++){
            account a = Reservation.get(i);
            if(a != null){
                System.out.println(i + "hrs:   " + a.getName());
            }
            else{
                System.out.print(i + "hrs: ");
                System.out.println(" available ");
            }
        }
    }

    //EFFECT: Return true and print something if the customer can be find on the reservation list
    // if the customer can not be found, return false and print something.
    public Boolean verifyReservation(account a, int ReservationTime){
        account acc1 = Reservation.get(ReservationTime);
        if(acc1 == null){
            System.out.println("There is no customer reserved at that time");
            return false;
        }
        if(acc1.getName().equals(a.getName())){
            System.out.println("Yes the customer is reserved at that time");
        }
        return true;
    }

    //EFFECT: return true if the customer is reserved at the reservation time
    public boolean confirmReservedName(String aName, int ReservationTime) {
        account acc1 = Reservation.get(ReservationTime);
        String acc1Name = acc1.getName();
        boolean sPersonReserved = acc1Name.equals(aName);
        return sPersonReserved;
    }

    //EFFECT: used as a helper to test constructor, get the size of the Reservation.
    public int getReservationSize(){
        return (Reservation.size()-1);
    }

    //EFFECT: used as a helper to test constructor, return the maxTime defined.
    public int getMaxTime(){
        return maxTime;
    }
    


    //MODIFY: this and account
    //EFFECT: change the customer's original reservation time to the his/her new reservation time
    // public void ChangingBooking(account a1, int NewTime ){
    //   int ReservedTime = a1.getReservationTime();
    //     System.out.print(a1.getName() + "'s time is changing from " + ReservedTime);
    //     System.out.println(" to " + NewTime);
    //     Reservation.set(ReservedTime, null);
    //     Reservation.set(NewTime, a1);
    //     a1.setReservationTime(NewTime);
}