package implementation;

import Interface.MarvelSeries;

public class ComicBook implements MarvelSeries {
    private String name;

    public ComicBook(String name) {this.name = name; }

    @Override
    public void printseries() {
        System.out.println("FromComicBook: " + name);
    }
}
