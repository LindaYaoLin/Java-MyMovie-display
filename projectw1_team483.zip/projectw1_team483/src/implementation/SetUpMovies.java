package implementation;


import java.util.ArrayList;
import java.util.Map;

public class SetUpMovies {

    public SetUpMovies(){};

    public void setupMovies(Map<String,ArrayList<AbstMovies>> Movies){
        AbstMovies movie1 = new Movies("Thor:Ragnarok");
        AbstMovies movie2 = new Movies("Pride and Prejudice");
        AbstMovies movie3 = new Movies("Spider-Man: Homecoming");
        AbstMovies movie4 = new Movies("Split");
        AbstMovies movie5 = new Movies ("The Nun");
        AbstMovies movie6 = new Movies ("The Grand Budapest Hotel");
        AbstMovies movie7 = new MoviesCS("Venom",18);
        AbstMovies movie8 = new MoviesCS("Gone with the wind",21);
        ArrayList<AbstMovies> comedy = new ArrayList<>();
        ArrayList<AbstMovies> marvel = new ArrayList<>();
        ArrayList<AbstMovies> thriller = new ArrayList<>();
        ArrayList<AbstMovies> romance = new ArrayList<>();
        comedy.add(movie6);
        marvel.add(movie1);
        marvel.add(movie3);
        marvel.add(movie7);
        thriller.add(movie4);
        thriller.add(movie5);
        romance.add(movie2);
        romance.add(movie8);
        Movies.put("Comedy",comedy);
        Movies.put("Marvel",marvel);
        Movies.put("Thriller",thriller);
        Movies.put("Romance",romance);
    }

    public void setupInformation(){
        Movies s1 = new Movies("Spider-Man(2002 film)");
        MoviesCS s2 = new MoviesCS("Spider-Man 2",4);
        MoviesCS s3 = new MoviesCS("Spider-Man 3",7);
        MoviesCS s4 = new MoviesCS("The Amazing Spider-Man",12);
        MoviesCS s5 = new MoviesCS("The Amazing Spider-Man 2",14);
        MoviesCS s6 = new MoviesCS("Spider-Man: Homecoming(2017)",17);
        s2.addprequel(s1);
        s1.addsequel(s2);
        s1.addsequel(s3);
        s1.addsequel(s4);
        s1.addsequel(s5);
        s1.addsequel(s6);
        s2.printprequel(s2.prequel);
        s1.printsequel(s1.sequel);
    }

    public void setupInformation2(){
        Movies s1= new Movies("Harry Potter and the Sorcerer's Stone (2001)");
        MoviesCS s2 = new MoviesCS("Harry Potter and the Chamber of Secrets (2002)",2);
        MoviesCS s3 = new MoviesCS("Harry Potter and the Prisoner of Azkaban (2004)",4);
        MoviesCS s4 = new MoviesCS("Harry Potter and the Goblet of Fire (2005) ",5);
        MoviesCS s5 = new MoviesCS("Harry Potter and the Order of the Phoenix (2007)",7);
        MoviesCS s6 = new MoviesCS("Harry Potter and the Half-Blood Prince (2009) ",9);
        MoviesCS s7 = new MoviesCS("Harry Potter and the Deathly Hallows: Part 1 ",10);
        MoviesCS s8 = new MoviesCS("Harry Potter and the Deathly Hallows: Part 2",11);
        MoviesCS s9 = new MoviesCS("Fantastic Beasts and Where to Find Them ",16);
        MoviesCS s10 = new MoviesCS("Fantastic Beasts: The Crimes of Grindelwald",18);
        s2.addprequel(s1);
        s1.addsequel(s2);
        s1.addsequel(s3);
        s1.addsequel(s4);
        s1.addsequel(s5);
        s1.addsequel(s6);
        s1.addsequel(s7);
        s1.addsequel(s8);
        s1.addsequel(s9);
        s1.addsequel(s10);
        s2.printprequel(s2.prequel);
        s1.printsequel(s1.sequel);
    }

    public Series setupMarvelseries(){
        Series s0 = new Series("Marvel Series");
        Series s1 = new Series("X-Men Series");
        s1.add(new ComicBook("X-Men 2000"));
        s1.add(new ComicBook("X2 2003"));
        s1.add(new ComicBook("X-Men Origins: Wolverine 2009"));
        s0.add(new ComicBook("Deadpool 2016"));
        s0.add(s1);
        Series s2 = new Series("Avenger Series");
        s2.add(new ComicBook("Iron Man 2008"));
        s2.add(new ComicBook("The Incredible Hulk 2008"));
        s2.add(new ComicBook("The Avengers 2012"));
        s2.add(new ComicBook("Agents of S.H.I.E.L.D. 2013"));
        s0.add(s2);
        Series s3 = new Series ("Fantastic Four Series");
        s3.add(new ComicBook("The Fantastic Four 1994"));
        s3.add(new ComicBook("Fantastic Four 2005"));
        s3.add(new ComicBook("Fantastic Four: Rise of the Silver Surfer 2007"));
        s0.add(s3);
        return s0;
    }
}
