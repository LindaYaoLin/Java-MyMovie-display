package implementation;

import Interface.Saveble;
import Interface.Loadable;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Observable;

public class account extends Observable implements Saveble,Loadable {

    private String name;
    private int ReservationTime;
    private String moviename;

    // EFFECT: constructed an account with customer's name, reserved time and reserved movie.
    public account(String name,String moviename){
        System.out.println("Customer name: " + name);
        System.out.println("Movie: " + moviename);
        this.name = name;
        this.ReservationTime = 0;
        this.moviename = moviename;
        addObserver(new AccountObserver());
    }

    // EFFECT: get the name of the customer from the account.
    public String getName() { return name; }
    public String getMovie() {return moviename;}


    public int getReservationTime(){return ReservationTime; }

    //EFFECT:
    public int confirmation(){
        System.out.println(name + ": Confirming that I am booked at " + ReservationTime);
        setChanged();
        notifyObservers(ReservationTime);
        return ReservationTime;
    }


    //EFFECT: set the reservation time of the customer to the time the customer reserved
    public void setReservationTime(int time){
        ReservationTime = time;
    }

    @Override
    public void save(account a) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get("inputfile.txt"));
        PrintWriter writer = new PrintWriter("outputfile.txt","UTF-8");
        lines.add (a.getName() + " " + a.getMovie());
        System.out.println("---------------------------");
        System.out.println("Registration List: ");
        for (String line : lines) {
            ArrayList<String> partsOfLine = splitOnSpace(line);
           System.out.println ( partsOfLine.get(0) + ", " +  partsOfLine.get(1));
            writer.println(line);
        }
     writer.close();
    }

    @Override
    public void load(String str) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get(str));
        ArrayList<account> acc = new ArrayList<>();
        for (String line : lines) {
            ArrayList<String> partsOfLine = splitOnSpace(line);
            account a1 = new account(partsOfLine.get(0),partsOfLine.get(1));
            acc.add(a1);
        }
    }

    public static ArrayList<String> splitOnSpace(String line) {
        String[] splits = line.split(" ");
        return new ArrayList<>(Arrays.asList(splits));
    }
}



