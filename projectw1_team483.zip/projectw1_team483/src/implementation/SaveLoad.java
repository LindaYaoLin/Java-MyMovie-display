package implementation;

import Interface.Loadable;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SaveLoad implements Loadable {

    @Override
    public void load(String str) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get(str));
        for (String line : lines) {
            ArrayList<String> partsOfLine = splitOnSpace(line);
            System.out.print("Name: " + partsOfLine.get(0) + " ");
            System.out.println("Movies: " + partsOfLine.get(1));

        }
    }


    public static ArrayList<String> splitOnSpace(String line) {
        String[] splits = line.split(" ");
        return new ArrayList<>(Arrays.asList(splits));
    }
}

