package implementation;

import java.util.Objects;

public abstract class AbstMovies {
    protected String name;


    public AbstMovies(String name) {
        this.name = name;
    }

    public abstract void print();


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AbstMovies)) return false;
        AbstMovies that = (AbstMovies) o;
        return Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {

        return Objects.hash(name);
    }
}

