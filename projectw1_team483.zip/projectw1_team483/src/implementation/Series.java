package implementation;

import Interface.MarvelSeries;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Series implements MarvelSeries {
    private List<MarvelSeries> marvelSeries = new ArrayList<>();
    private String name;

    public Series (String name) {
        this.name = name;
    }

    @Override
    public void printseries() {
        System.out.println("Series: " + name);
       for (MarvelSeries marvelSerie: marvelSeries)
           marvelSerie.printseries();
    }

    public void add(MarvelSeries ms){
        marvelSeries.add(ms);
    }
    public void remove(MarvelSeries ms){
        marvelSeries.remove(ms);
    }

}
