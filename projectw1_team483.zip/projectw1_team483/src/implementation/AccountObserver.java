package implementation;

import com.sun.org.apache.xpath.internal.SourceTree;

import java.util.Observable;
import java.util.Observer;

public class AccountObserver implements Observer {
    @Override
    public void update(Observable o, Object arg) {
        System.out.println("Congratulation! Your account has been created successfully!");
        System.out.println("Please come at "+ arg + " 'o clock today with your electronic ticket");
        System.out.println("We are looking forward to your visit.");
    }
}
