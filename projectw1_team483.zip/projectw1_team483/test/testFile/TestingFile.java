package testFile;

import Exception.MovieNotExistException;
import Exception.NoExistingTimeException;

public class TestingFile {
    private String name;
    private String mv;
    private int time;

    public TestingFile(String name, String mv, int time){
        this.name = name;
        this.mv = mv;
        this.time = time;
    }

    public void Testcase() throws MovieNotExistException, NoExistingTimeException {
        if (time>20) {
            throw new NoExistingTimeException();
        }
        else if(!(mv.equals ("Comedy"))){
           throw new MovieNotExistException();
        }
    }

    public void Analyze(){
        try{
            Testcase();
        }
        catch (NoExistingTimeException e) {
            System.out.println("No Time");
        } catch (MovieNotExistException e) {
            System.out.println("No mv");
        }
    }
}




