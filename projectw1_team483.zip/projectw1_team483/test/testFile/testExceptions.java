package testFile;

import testFile.TestingFile;
import org.junit.jupiter.api.Test;
import Exception.NoExistingTimeException;
import Exception.MovieNotExistException;
import static org.junit.jupiter.api.Assertions.fail;

public class testExceptions {

    @Test
    public void MovieexistTimeexist(){
        TestingFile tf = new TestingFile("a","Comedy",3);
        try {
            tf.Testcase();
        }
        catch(NoExistingTimeException e){
            fail("do not expect that");
        } catch (MovieNotExistException e) {
            fail("do not expect that either");
        }
    }

    @Test
    public void MovieexistTimedoesNot(){
        TestingFile tff = new TestingFile("a","Comedy",23);
        try {
            tff.Testcase();
        }
        catch(NoExistingTimeException e){

        } catch (MovieNotExistException e) {
           fail("do not expect that");
        }
    }

    @Test void MovieDoesNotTimeExist(){
        TestingFile tffa = new TestingFile("a","Love",13);
        try {
            tffa.Testcase();
        }
        catch(NoExistingTimeException e){
            fail("do not expect that");
        } catch (MovieNotExistException e) {
            System.out.println("please print");
        }
    }

    @Test void BothDoesNotExist(){
        TestingFile tiff = new TestingFile("a","Love",78);
        try {
            tiff.Testcase();
        }
        catch(NoExistingTimeException e){

        } catch (MovieNotExistException e) {
            fail("the exception would be caught by the first one");
        }
    }
}
