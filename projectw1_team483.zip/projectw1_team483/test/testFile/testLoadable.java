package testFile;

import implementation.SaveLoad;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import implementation.account;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class testLoadable {

    @Test
    public void testloadable() throws IOException {
        final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        SaveLoad sl1 = new SaveLoad();
        sl1.load("testfile.txt");
        assertEquals("Name: Mike Movies: Love\r\n",outContent.toString());
    }
}
