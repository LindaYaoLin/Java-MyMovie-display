package testfile;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import implementation.MyMovie;
import implementation.account;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class testMyMovie {
    private static String CUSTOMERNAME = "Elina";
    private static String MOVIETYPE = "Pride and Prejudice";

    private MyMovie mm;

    @BeforeEach
    public void RunBefore(){
        mm = new MyMovie();
    }

    @Test
    public void testConstructor(){
        assertEquals(mm.getReservationSize(), mm.getMaxTime());
    }

    @Test
    public void testMakeNewReservation(){
        int ReservationTime = 12;
        account a1 = new account(CUSTOMERNAME,MOVIETYPE);
        mm.MakeNewReservation(a1,ReservationTime);

        assertEquals(a1.getName(),CUSTOMERNAME);
        assertEquals(a1.getReservationTime(),ReservationTime);

    }


    @Test
    public void testVerificationIfaIsNull(){
        int ReservationTime = 12;
        account a1 = new account(CUSTOMERNAME,MOVIETYPE);
        assertFalse(mm.verifyReservation(a1,ReservationTime));
    }

    @Test
    public void testVerificationIfaIsNotNull(){
        int ReservationTime = 12;
        account a1 = new account(CUSTOMERNAME,MOVIETYPE);
        mm.MakeNewReservation(a1,ReservationTime);
        assertTrue(mm.verifyReservation(a1,ReservationTime));
    }

    @Test
    public void testConformReservedName(){
        int ReservationTime = 12;
        account a1 = new account(CUSTOMERNAME,MOVIETYPE);
        mm.MakeNewReservation(a1,ReservationTime);
        assertTrue(mm.confirmReservedName(CUSTOMERNAME,ReservationTime));
    }



}

