package testFile;

import implementation.account;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class testSaveble {
   @Test
    public void testsavable() throws IOException {
      final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
      System.setOut(new PrintStream(outContent));
        account a = new account("k","l");
        a.save(a);
        assertEquals("Customer name: k\r\n" +
                "Movie: l\r\n" +
                "---------------------------\r\n" +
                "Registration List: \r\n" +
                "Mike,Love\r\n" +
                "Ali,Gone\r\n" +
                "Elisa,split\r\n" +
                "k,l\r\n",outContent.toString());
    }
}

